# NOVA_LAUNCHER_CLONE

▷ Create an android app like NOVA LAUNCHER

▷ Full Video Tutorial Playlist here: https://www.youtube.com/watch?v=tml0oqLyY78&list=PLxabZQCAe5fhGgSue40-_DjfFc_5EThhr <br />

▷ Become a Patreon: https://www.patreon.com/simpleCoder<br />
▷ Donate with PayPal: https://www.paypal.me/simcoder<br />
▷ Twitter: https://twitter.com/S1mpleCoder<br />
▷ GitHub : https://goo.gl/88FHk4<br />

▷ If you have any question please ask, I'll try to answer to every question and even look at your code if that is necessary.


**Important Links**
----

P.S: Check the branches for the most recent piece of code. I'm only going to merge everything to the master when the series is completed

